<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->boolean('project_auth_require_verified_email')->default(false)->after('public_api');
            $table->json('project_auth_email_verification_config')->nullable()->after('project_auth_require_verified_email');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('projects', function (Blueprint $table) {
            $table->dropColumn([
                'project_auth_require_verified_email',
                'project_auth_email_verification_config',
            ]);
        });
    }
};
