import * as React from "react"
import { JSX, useCallback, useEffect, useRef, useState } from "react"
import { useLexicalComposerContext } from "@lexical/react/LexicalComposerContext"
import { useLexicalEditable } from "@lexical/react/useLexicalEditable"
import { mergeRegister } from "@lexical/utils"
import {
  $getNodeByKey,
  $getSelection,
  $isNodeSelection,
  COMMAND_PRIORITY_HIGH,
  KEY_ESCAPE_COMMAND,
  NodeKey,
  SELECTION_CHANGE_COMMAND,
} from "lexical"
import { ErrorBoundary } from "react-error-boundary"

import EquationEditor from "@/components/editor/editor-ui/equation-editor"
import KatexRenderer from "@/components/editor/editor-ui/katex-renderer"
import { $isEquationNode } from "@/components/editor/nodes/equation-node"

type EquationComponentProps = {
  equation: string
  inline: boolean
  nodeKey: NodeKey
}

export default function EquationComponent({
  equation,
  inline,
  nodeKey,
}: EquationComponentProps): JSX.Element {
  const [editor] = useLexicalComposerContext()
  const isEditable = useLexicalEditable()
  const [equationValue, setEquationValue] = useState(equation)
  const [showEquationEditor, setShowEquationEditor] = useState<boolean>(false)
  const inputRef = useRef(null)

  const onHide = useCallback(
    (restoreSelection?: boolean) => {
      setShowEquationEditor(false)
      editor.update(() => {
        const node = $getNodeByKey(nodeKey)
        if ($isEquationNode(node)) {
          node.setEquation(equationValue)
          if (restoreSelection) {
            node.selectNext(0, 0)
          }
        }
      })
    },
    [editor, equationValue, nodeKey]
  )

  useEffect(() => {
    if (!showEquationEditor && equationValue !== equation) {
      setEquationValue(equation)
    }
  }, [showEquationEditor, equation, equationValue])

  useEffect(() => {
    if (!isEditable) {
      return
    }
    if (showEquationEditor) {
      return mergeRegister(
        editor.registerCommand(
          SELECTION_CHANGE_COMMAND,
          (payload) => {
            const activeElement = document.activeElement
            const inputElem = inputRef.current
            if (inputElem !== activeElement) {
              onHide()
            }
            return false
          },
          COMMAND_PRIORITY_HIGH
        ),
        editor.registerCommand(
          KEY_ESCAPE_COMMAND,
          (payload) => {
            const activeElement = document.activeElement
            const inputElem = inputRef.current
            if (inputElem === activeElement) {
              onHide(true)
              return true
            }
            return false
          },
          COMMAND_PRIORITY_HIGH
        )
      )
    } else {
      return editor.registerUpdateListener(({ editorState }) => {
        const isSelected = editorState.read(() => {
          const selection = $getSelection()
          return (
            $isNodeSelection(selection) &&
            selection.has(nodeKey) &&
            selection.getNodes().length === 1
          )
        })
        if (isSelected) {
          setShowEquationEditor(true)
        }
      })
    }
  }, [editor, nodeKey, onHide, showEquationEditor, isEditable])

  return (
    <>
      {showEquationEditor && isEditable ? (
        <EquationEditor
          equation={equationValue}
          setEquation={setEquationValue}
          inline={inline}
          ref={inputRef}
        />
      ) : (
        <ErrorBoundary onError={(e) => editor._onError(e)} fallback={null}>
          <KatexRenderer
            equation={equationValue}
            inline={inline}
            onDoubleClick={() => {
              if (isEditable) {
                setShowEquationEditor(true)
              }
            }}
          />
        </ErrorBoundary>
      )}
    </>
  )
}
